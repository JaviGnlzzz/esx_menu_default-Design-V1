fx_version 'adamant'

game 'gta5'

author 'TusMuertos.#4903'

description 'Menu Default rediseñado'

ui_page {
	'html/ui.html'
}

client_scripts {
	'client/main.lua'
}
